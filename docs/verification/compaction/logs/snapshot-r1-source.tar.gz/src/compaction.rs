use std::sync::{Arc, Mutex};

use serde::Deserialize;

use minicore_runtime::LoopId;
use minicore_runtime::history::HistoryItem;
use minicore_runtime::model::{ModelMessage, ReasoningPreference};
use minicore_runtime::value::BoundedText;

use crate::ids::SessionId;
use crate::store::{HistoryPrefix, MAX_SUMMARY_FILE_BYTES, Store};

pub(crate) const SUMMARY_FORMAT_VERSION: u32 = 1;
pub(crate) const MAX_SUMMARY_CONTENT_BYTES: usize = 64 * 1024;

#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
struct SummarySnapshot {
    format_version: u32,
    session_id: SessionId,
    model: String,
    reasoning: ReasoningPreference,
    source: SummarySource,
    summary: String,
}

#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
struct SummarySource {
    prefix_bytes: u64,
    covered_loop_count: u64,
    covered_item_count: u64,
    last_loop_id: Option<LoopId>,
    sha256: String,
}

#[derive(Clone)]
struct LoadedSummary {
    content: BoundedText,
    covered_item_count: usize,
}

/// Session-local derived prompt state. It is deliberately separate from the
/// session presentation and the global model catalog.
pub(crate) struct CompactionState {
    snapshot: Mutex<Option<LoadedSummary>>,
}

pub(crate) struct HistoryProjection {
    pub(crate) summary: BoundedText,
    pub(crate) suffix: Vec<HistoryItem>,
}

impl CompactionState {
    pub(crate) fn new() -> Arc<Self> {
        Arc::new(Self {
            snapshot: Mutex::new(None),
        })
    }

    fn install(&self, summary: LoadedSummary) {
        *self.snapshot.lock().unwrap() = Some(summary);
    }

    pub(crate) fn project(&self, base: &[HistoryItem]) -> Option<HistoryProjection> {
        let summary = self.snapshot.lock().unwrap().clone()?;
        if summary.covered_item_count > base.len() {
            return None;
        }
        Some(HistoryProjection {
            summary: summary.content,
            suffix: base[summary.covered_item_count..].to_vec(),
        })
    }
}

/// Loads only a validated derived snapshot. Any snapshot problem returns an
/// empty state; the already-loaded core history remains authoritative.
pub(crate) async fn load_state(
    store: &Store,
    session_id: SessionId,
    history: &[HistoryItem],
) -> Arc<CompactionState> {
    let state = CompactionState::new();
    let Some(bytes) = store
        .read_summary_bytes(session_id)
        .await
        .ok()
        .flatten()
    else {
        return state;
    };
    let Some(snapshot) = decode_snapshot(&bytes) else {
        return state;
    };
    let Some(prefix) = store
        .read_history_prefix(session_id, snapshot.source.prefix_bytes)
        .await
        .ok()
        .flatten()
    else {
        return state;
    };
    let Some(summary) = validate_snapshot(&snapshot, session_id, history.len(), &prefix) else {
        return state;
    };
    state.install(summary);
    state
}

fn decode_snapshot(bytes: &[u8]) -> Option<SummarySnapshot> {
    if bytes.len() > MAX_SUMMARY_FILE_BYTES {
        return None;
    }
    serde_json::from_slice(bytes).ok()
}

fn validate_snapshot(
    snapshot: &SummarySnapshot,
    session_id: SessionId,
    history_len: usize,
    prefix: &HistoryPrefix,
) -> Option<LoadedSummary> {
    let _provenance_reasoning = snapshot.reasoning;
    if snapshot.format_version != SUMMARY_FORMAT_VERSION
        || snapshot.session_id != session_id
        || !valid_provenance(&snapshot.model)
        || snapshot
            .model
            .parse::<minicore_runtime::model::ModelRef>()
            .is_err()
        || snapshot.source.prefix_bytes != prefix.prefix_bytes
        || snapshot.source.covered_loop_count != prefix.covered_loop_count
        || snapshot.source.covered_item_count != prefix.covered_item_count
        || snapshot.source.last_loop_id != prefix.last_loop_id
        || snapshot.source.sha256 != prefix.sha256
        || !valid_sha256(&snapshot.source.sha256)
    {
        return None;
    }
    let covered_item_count = usize::try_from(snapshot.source.covered_item_count).ok()?;
    if covered_item_count == 0 || covered_item_count > history_len {
        return None;
    }
    let content = BoundedText::new_with_max_bytes(
        &snapshot.summary,
        MAX_SUMMARY_CONTENT_BYTES,
    )
    .ok()?;
    if content.is_empty() || ModelMessage::user(content.as_str()).is_err() {
        return None;
    }
    Some(LoadedSummary {
        content,
        covered_item_count,
    })
}

fn valid_provenance(value: &str) -> bool {
    !value.is_empty()
        && value.len() <= 256
        && value.chars().all(|character| !character.is_control())
}

fn valid_sha256(value: &str) -> bool {
    value.len() == 64
        && value.bytes().all(|byte| {
            byte.is_ascii_digit() || (b'a'..=b'f').contains(&byte)
        })
}